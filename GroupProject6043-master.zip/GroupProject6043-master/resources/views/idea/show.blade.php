<h1>{{ $idea->title }}</h1>
<p class="lead">{{ $idea->destination }}</p>
<p class="lead">{{ $idea->start_date }}</p>
<hr>

<a href="{{ route('idea.index') }}" class="btn btn-info">Back to all ideas</a>

@if(Auth::user()->id == $idea->user_id)
<a href="{{ route('idea.edit', $idea->id) }}" class="btn btn-primary">Edit idea</a>
<a href="{{ route('idea.delete', $idea->id) }}" class="btn btn-primary">Delete idea</a>
@endif

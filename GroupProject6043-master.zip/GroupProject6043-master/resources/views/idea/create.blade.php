

<script type="text/javascript">
$(function(){
        $(".datepicker").datepicker({
            changeMonth: true,
            changeYear: true,
            format: 'YYYY-MM-DD',
            showButtonPanel: true,
            minDate: 0,
            // onSelect: function (pickup_date) {
                // $("#startdatepicker").datepicker('option', 'minDate', start_date)
            // };
            onSelect: function(dateText, inst) {
                var date1 = $.datepicker.parseDate($.datepicker._defaults.dateFormat, $("#startdatepicker").val());
                var date2 = $.datepicker.parseDate($.datepicker._defaults.dateFormat, $("#enddatepicker").val());
                var selectedDate = $.datepicker.parseDate($.datepicker._defaults.dateFormat, dateText);
                
                if (!date1 || date2) {
                    $("#startdatepicker").val(dateText);
                    $("#enddatepicker").val("");
                    
                    $(this).datepicker();
                    } 
                else if( selectedDate < date1 ) {
                    $("#enddatepicker").val( $("#startdatepicker").val() );
                    $("#startdatepicker").val( dateText );
                    $(this).datepicker();
                    } 
                else {
                    $("#enddatepicker").val(dateText);
                    $(this).datepicker();
                }
            }
        });
    });
</script>

        
@include('partials.alerts.errors')
        
        <!-- Show Success message as user submit the form -->
        @if(session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
        @endif

{!! Form::open(['route' => 'idea.store']) !!}

<div class="form-group">
    {!! Form::label('title', 'Title') !!}
    {!! Form::text('title', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('destination', 'Destination') !!}
    {!! Form::text('destination', null, ['class' => 'form-control']) !!}
</div>

<div class="datepicker" id="startdatepicker">
    {!! Form::label('start_date', 'Select Start Date') !!}
    {!! Form::input('date', 'start_date', null , ['id' => 'startdatepicker']) !!}
</div>

<div class="datepicker" id="enddatepicker">
    {!! Form::label('end_date', 'Select End Date') !!}
    {!! Form::input('date', 'end_date', null , ['id' => 'enddatepicker']) !!}
</div>

<div class="form-group">
    {!! Form::label('tags', 'Tags') !!}
    {!! Form::text('tags', null, ['class' => 'form-control']) !!}
</div>

{!! Form::submit('Submit', ['class' => 'btn btn-info']) !!}

{!! Form::close() !!}
<a href="{{ route('idea.index') }}" class="btn btn-info">Back to all ideas</a>

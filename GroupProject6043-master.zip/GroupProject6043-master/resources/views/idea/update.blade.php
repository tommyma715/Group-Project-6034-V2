@if(session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
        @endif
    
    @if(Auth::user()->id == $idea->user_id)


    <h1>Editing "{{ $idea->title }}"</h1>
    <p class="lead">Edit and save this diea below, or <a href="{{ route('idea.index') }}">go back to all ideas.</a></p>
    <hr>

    @include('partials.alerts.errors')

    @if(Session::has('flash_message'))
    <div class="alert alert-success">
        {{ Session::get('flash_message') }}
    </div>
    @endif

    {!! Form::model($idea, [
    'method' => 'PATCH',
    'route' => ['idea.update', $idea->id]
]) !!}

<div class="form-group">
    {!! Form::label('title', 'Title:', ['class' => 'control-label']) !!}
    {!! Form::text('title', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('destination', 'Destination:', ['class' => 'control-label']) !!}
    {!! Form::text('destination', null, ['class' => 'form-control']) !!}
</div>

<div class="datepicker" id="startdatepicker">
    {!! Form::label('start_date', 'Select Start Date') !!}
    {!! Form::input('date', 'start_date', null , ['id' => 'startdatepicker']) !!}
</div>

<div class="datepicker" id="enddatepicker">
    {!! Form::label('end_date', 'Select End Date') !!}
    {!! Form::input('date', 'end_date', null , ['id' => 'enddatepicker']) !!}
</div>

<div class="form-group">
    {!! Form::label('tags', 'Tags') !!}
    {!! Form::text('tags', null, ['class' => 'form-control']) !!}
</div>


{!! Form::submit('Update Idea', ['class' => 'btn btn-primary']) !!}

{!! Form::close() !!}

        @endif 
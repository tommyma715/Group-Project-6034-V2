@if(session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
        @endif
        <p>
<a href="{{ route ('idea.myidea')}}" class="btn btn-info">Edit my idea</a>
</p>
<p>
<a href="{{ route ('idea.create')}}" class="btn btn-info">Create</a>
</p>


@foreach($ideas as $idea)
    <h3>{{ $idea->title }}</h3>
    <p>{{ $idea->destination}}</p>
    <p>
        <a href="{{ route('idea.show', $idea->id) }}" class="btn btn-info">View Task</a>
        
    </p>
    <hr>
@endforeach
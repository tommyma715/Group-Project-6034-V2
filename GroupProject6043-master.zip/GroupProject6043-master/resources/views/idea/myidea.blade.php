
@foreach($ideas as $idea)
@if(Auth::user()->id == $idea->user_id)
    <h3>{{ $idea->title }}</h3>
    <p>{{ $idea->destination}}</p>
    <p>
        <a href="{{ route('idea.edit', $idea->id) }}" class="btn btn-info">Edit Task</a>
        <a href="{{ route('idea.delete', $idea->id) }}" class="btn btn-danger">Delete this idea</a>
    </p>
    @endif 
@endforeach

<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});



Auth::routes();

Route::resource('idea', 'IdeaController');
Route::get('/home', 'HomeController@index')->name('home');

Route::get('/idea', 'IdeaController@index')->name('idea.index');
Route::get('/myidea', 'IdeaController@myidea')->name('idea.myidea');

Route::get('idea/create', 'IdeaController@create')->name('idea.create');
Route::post('idea/create', 'IdeaController@store')->name('idea.store');

Route::get('idea/show/{id}', 'IdeaController@show')->name('idea.show');


Route::get('idea/delete/{id}', 'IdeaController@delete')->name('idea.delete');
<?php /* /Applications/XAMPP/xamppfiles/htdocs/GroupProject6043-master/resources/views/idea/editshow/index.blade.php */ ?>


<?php $__currentLoopData = $ideas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(Auth::user()->id == $idea->user_id): ?>
    <h3><?php echo e($idea->title); ?></h3>
    <p><?php echo e($idea->destination); ?></p>
    <p>
        <a href="<?php echo e(route('idea.edit', $idea->id)); ?>" class="btn btn-info">Edit Task</a>
        <a href="<?php echo e(route('idea.delete', $idea->id)); ?>" class="btn btn-danger">Delete this idea</a>
    </p>
    <?php endif; ?> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /* /Applications/XAMPP/xamppfiles/htdocs/GroupProject6043-master/resources/views/idea/destroy.blade.php */ ?>

<h1><?php echo e($idea->title); ?></h1>
<p class="lead"><?php echo e($idea->description); ?></p>
<hr>

<div class="row">
    <div class="col-md-6">
        <a href="<?php echo e(route('idea.index')); ?>" class="btn btn-info">Back to all idea</a>
        <a href="<?php echo e(route('idea.edit', $idea->id)); ?>" class="btn btn-primary">Edit idea</a>
    </div>
    <div class="col-md-6 text-right">
        <?php echo Form::open([
            'method' => 'DELETE',
            'route' => ['idea.delete', $idea->id]
        ]); ?>

            <?php echo Form::submit('Delete this idea?', ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

    </div>
</div>

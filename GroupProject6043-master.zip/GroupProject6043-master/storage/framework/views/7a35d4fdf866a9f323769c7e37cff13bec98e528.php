<?php /* /Applications/XAMPP/xamppfiles/htdocs/GroupProject6043-master/resources/views/idea/create.blade.php */ ?>


<script type="text/javascript">
$(function(){
        $(".datepicker").datepicker({
            changeMonth: true,
            changeYear: true,
            format: 'YYYY-MM-DD',
            showButtonPanel: true,
            minDate: 0,
            // onSelect: function (pickup_date) {
                // $("#startdatepicker").datepicker('option', 'minDate', start_date)
            // };
            onSelect: function(dateText, inst) {
                var date1 = $.datepicker.parseDate($.datepicker._defaults.dateFormat, $("#startdatepicker").val());
                var date2 = $.datepicker.parseDate($.datepicker._defaults.dateFormat, $("#enddatepicker").val());
                var selectedDate = $.datepicker.parseDate($.datepicker._defaults.dateFormat, dateText);
                
                if (!date1 || date2) {
                    $("#startdatepicker").val(dateText);
                    $("#enddatepicker").val("");
                    
                    $(this).datepicker();
                    } 
                else if( selectedDate < date1 ) {
                    $("#enddatepicker").val( $("#startdatepicker").val() );
                    $("#startdatepicker").val( dateText );
                    $(this).datepicker();
                    } 
                else {
                    $("#enddatepicker").val(dateText);
                    $(this).datepicker();
                }
            }
        });
    });
</script>

        
<?php echo $__env->make('partials.alerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <!-- Show Success message as user submit the form -->
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>

<?php echo Form::open(['route' => 'idea.store']); ?>


<div class="form-group">
    <?php echo Form::label('title', 'Title'); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('destination', 'Destination'); ?>

    <?php echo Form::text('destination', null, ['class' => 'form-control']); ?>

</div>

<div class="datepicker" id="startdatepicker">
    <?php echo Form::label('start_date', 'Select Start Date'); ?>

    <?php echo Form::input('date', 'start_date', null , ['id' => 'startdatepicker']); ?>

</div>

<div class="datepicker" id="enddatepicker">
    <?php echo Form::label('end_date', 'Select End Date'); ?>

    <?php echo Form::input('date', 'end_date', null , ['id' => 'enddatepicker']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('tags', 'Tags'); ?>

    <?php echo Form::text('tags', null, ['class' => 'form-control']); ?>

</div>

<?php echo Form::submit('Submit', ['class' => 'btn btn-info']); ?>


<?php echo Form::close(); ?>

<a href="<?php echo e(route('idea.index')); ?>" class="btn btn-info">Back to all ideas</a>

<?php /* /Applications/XAMPP/xamppfiles/htdocs/GroupProject6043-master/resources/views/idea/show.blade.php */ ?>
<h1><?php echo e($idea->title); ?></h1>
<p class="lead"><?php echo e($idea->destination); ?></p>
<p class="lead"><?php echo e($idea->start_date); ?></p>
<hr>

<a href="<?php echo e(route('idea.index')); ?>" class="btn btn-info">Back to all ideas</a>

<?php if(Auth::user()->id == $idea->user_id): ?>
<a href="<?php echo e(route('idea.edit', $idea->id)); ?>" class="btn btn-primary">Edit idea</a>
<a href="<?php echo e(route('idea.delete', $idea->id)); ?>" class="btn btn-primary">Delete idea</a>
<?php endif; ?>

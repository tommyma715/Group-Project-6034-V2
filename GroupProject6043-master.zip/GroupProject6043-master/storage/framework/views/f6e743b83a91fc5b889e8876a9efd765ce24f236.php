<?php /* /Applications/XAMPP/xamppfiles/htdocs/GroupProject6043-master/resources/views/idea/update.blade.php */ ?>
<?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
    
    <?php if(Auth::user()->id == $idea->user_id): ?>


    <h1>Editing "<?php echo e($idea->title); ?>"</h1>
    <p class="lead">Edit and save this diea below, or <a href="<?php echo e(route('idea.index')); ?>">go back to all ideas.</a></p>
    <hr>

    <?php echo $__env->make('partials.alerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(Session::has('flash_message')): ?>
    <div class="alert alert-success">
        <?php echo e(Session::get('flash_message')); ?>

    </div>
    <?php endif; ?>

    <?php echo Form::model($idea, [
    'method' => 'PATCH',
    'route' => ['idea.update', $idea->id]
]); ?>


<div class="form-group">
    <?php echo Form::label('title', 'Title:', ['class' => 'control-label']); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('destination', 'Destination:', ['class' => 'control-label']); ?>

    <?php echo Form::text('destination', null, ['class' => 'form-control']); ?>

</div>

<div class="datepicker" id="startdatepicker">
    <?php echo Form::label('start_date', 'Select Start Date'); ?>

    <?php echo Form::input('date', 'start_date', null , ['id' => 'startdatepicker']); ?>

</div>

<div class="datepicker" id="enddatepicker">
    <?php echo Form::label('end_date', 'Select End Date'); ?>

    <?php echo Form::input('date', 'end_date', null , ['id' => 'enddatepicker']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('tags', 'Tags'); ?>

    <?php echo Form::text('tags', null, ['class' => 'form-control']); ?>

</div>


<?php echo Form::submit('Update Idea', ['class' => 'btn btn-primary']); ?>


<?php echo Form::close(); ?>


        <?php endif; ?> 
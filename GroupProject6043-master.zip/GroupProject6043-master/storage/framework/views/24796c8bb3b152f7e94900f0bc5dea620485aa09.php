<?php /* /Applications/XAMPP/xamppfiles/htdocs/GroupProject6043-master/resources/views/idea/index.blade.php */ ?>
<?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <p>
<a href="<?php echo e(route ('idea.myidea')); ?>" class="btn btn-info">Edit my idea</a>
</p>
<p>
<a href="<?php echo e(route ('idea.create')); ?>" class="btn btn-info">Create</a>
</p>


<?php $__currentLoopData = $ideas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h3><?php echo e($idea->title); ?></h3>
    <p><?php echo e($idea->destination); ?></p>
    <p>
        <a href="<?php echo e(route('idea.show', $idea->id)); ?>" class="btn btn-info">View Task</a>
        
    </p>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
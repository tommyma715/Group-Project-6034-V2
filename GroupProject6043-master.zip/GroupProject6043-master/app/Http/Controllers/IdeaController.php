<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Idea;
use Auth;

class IdeaController extends Controller
{
    protected $redirectTo = '/home';

    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function create()
    {   
        $contact = new Idea;
        return view('idea.create',compact('contact'));
    }

    public function store(Request $request)
    {
        // validate the input data
        $this->validate($request, [
            'title' => 'required', 
            // validate with country list
            'destination' => 'required',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'tags' => 'required',
            // tags->seperate by ,
        ]);
        
        $contact = new Idea([
            'user_id' => Auth::user()->id,
            'title' => $request->get('title'),
            'destination' => $request->get('destination'),
            'start_date' => $request->get('start_date'),
            'end_date' => $request->get('end_date'),
            'tags' => $request->get('tags'),
        ]);

        $contact->save();
        
        return redirect()->route('idea.index')->with('message','Idea has been created!');

    }

    public function index()
    {
        $ideas = Idea::all();

        return view('idea.index')->withIdeas($ideas);
    }


    public function myidea()
    {   
        $ideas = Idea::all();

        return view('idea.myidea')->withIdeas($ideas);
    }

    public function show($id)
    {   
        $idea = Idea::findOrFail($id);
		return view('idea.show', compact('idea'));
  
    }


    public function edit($id)
    {
    $idea = Idea::findOrFail($id);

    return view('idea.update')->withIdea($idea);
    
    }


    public function delete($id)
    {
        
    $idea = Idea::findOrFail($id);

    $idea->delete();

    return redirect()->route('idea.index')->with('message','Idea has been deleted!');

    }

    // $idea->delete();

    // Session::flash('flash_message', 'Task successfully deleted!');

    // return redirect()->route('idea.index');

    // return view('idea.destroy', compact('idea'));
    


    public function update(Request $request, $id)
    {   


         //1. validate the inputted data 
         $this->validate($request, [
            'title' => 'required', 
            // validate with country list
            'destination' => 'required',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            // tags->seperate by ,
        ]);
		
		  //2. search the idea from database
          $idea = Idea::findOrFail($id);
          
          $input = $request->all();

          $idea->fill($input)->save();
      
          return redirect()->back()->with('message','Idea has been updated!');

		  //3. set the new values 
		//   $idea->title = $request->get('title');
		//   $idea->destination = $request->get('destination');
		//   $idea->start_date = $request->get('start_date');
        //   $idea->end_date = $request->get('end_date');
        //   $idea->tags = $request->get('tags');
          
		  //4. save the idea into database
		//   $idea->save();
 
		//    return redirect('/idea')->with('success', 'idea has been updated');
    }


}

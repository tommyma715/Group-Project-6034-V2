<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Idea extends Model
{
	public $timestamps = false;
	
	protected $fillable = [
      'id',
	  'user_id',
	  'title',
	  'destination',
      'start_date',
      'end_date',
      'tags'
	];
}
